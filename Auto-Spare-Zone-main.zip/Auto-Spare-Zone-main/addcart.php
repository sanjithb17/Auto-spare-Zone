<?php
include("dbconnect.php");

session_start();
extract($_POST);
$uid=$_SESSION['id'];
if(isset($btn))
{
$amount=0;
	$mq2=mysqli_query($conn,"select max(orderid) from addcart");
$mr2=mysqli_fetch_array($mq2);
$order=$mr2['max(orderid)']+1;
	for($i=0;$i<count($gid);$i++)
	{
	$amt=$price[$i]*$qty[$i];
	$amount+=$amt;
	mysqli_query($conn,"update addcart set price=$price[$i],quantity=$qty[$i],amount=$amt,status=1,orderid=order where id=$gid[$i]");
	$get=mysqli_query($conn,"select * from product where id=$pid[$i]");
	$quan=mysqli_fetch_array($get);
	$old=$quan['qty'];
	$new=$old-$qty[$i];
	$update=mysqli_query($conn,"update product set qty=$new where id=$pid[$i]");
	
	}

header("location:payment.php?id=".$order);
}


?>

<html>
<title>Spare Parts</title>
<style>

p
{
	color:#333300;
	text-align: center;
	text-transform: uppercase;
	 font-size:35px;
}

ul {
	padding:25px;
	
  list-style-type: none;
  overflow: hidden;
  background:#333300;
   background-repeat: no-repeat;
   background-size: 1420px  200px;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
   border-radius:10px;
}

li {
  float: left;
}

li a {
  display: block;
  color: #ffffff;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #666600;
}

.active {
  background-color: #666600;
}

#footer {
  border: 2px solid #333300;
  padding: 25px;
  background:#333300;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:20px;
}
#bg1 {

  padding:150px;
  background:url("images/car.jpg");
  background-repeat: no-repeat;
  background-size: 1420px  300px;
  border-radius:5px;
   border-radius:10px;
    text-align:left;
   font-size:35px;
   color:#cce6ff;
}

</style>
</head>
<ul>
	 <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
  <li><a  href="userhome.php"><strong>User Home Page</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a class="active" href="addcart.php"><strong>Add Cart</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="view.php"><strong>View Buying Product</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="index.php"><strong>LogOut</a></li>
</ul>
<br />
<br />
<p>Auto Spare Zone</p>
<div id="bg1"></div>

<!-- Form to display the cart items and quantity selection -->
<form name="form1" method="post" action="payment.php"> <!-- Make sure to set the action to a processing PHP file -->
    <table width="801" border="1" align="center" cellpadding="5">
        <tr>
            <th width="81" scope="col">Image</th>
            <th width="81" scope="col">Product</th>
            <th width="128" scope="col">Price</th>
            <th width="171" scope="col">Quantity</th>
            <th width="171" scope="col">Action</th>
        </tr>
        
        <?php
        // Fetch items in the cart for the user with status 0 (assumed to mean not checked out yet)
        $q1 = mysqli_query($conn, "SELECT * FROM addcart WHERE uid='$uid' AND status=0");
        $num = mysqli_num_rows($q1);
        
        // If the cart has items, display them
        if ($num > 0) {
            while ($r1 = mysqli_fetch_array($q1)) {
                // Fetch product details for each cart item
                $q3 = mysqli_query($conn, "SELECT * FROM product WHERE id=" . $r1['pid']);
                $r3 = mysqli_fetch_array($q3);
        ?>
        
        <!-- Display product information -->
        <tr>
            <td align="left"><img src="images/<?php echo $r3['img']; ?>" width="80" height="80" /></td>
            <td align="left"><?php echo $r3['name']; ?></td>
            <td align="left"><?php echo $r3['price']; ?></td>
            <td align="left">
                <!-- Input for quantity selection, based on the available stock for that product -->
                <input type="number" name="qty[]" required min="1" max="<?php echo $r3['qty']; ?>" value="1" />
                <input type="hidden" name="gid[]" value="<?php echo $r1['id']; ?>" />
                <input type="hidden" name="pid[]" value="<?php echo $r1['pid']; ?>" />
                <input type="hidden" name="price[]" value="<?php echo $r3['price']; ?>" />
            </td>
            <td align="left">
                <a href="removecart.php?did=<?php echo $r1['id']; ?>">Remove</a>
            </td>
        </tr>
        
        <?php
            }
        ?>
        
        <!-- Submit button for order processing -->
        <tr>
            <td colspan="6" align="center">
                <input type="submit" name="btn" value="Order" />
            </td>
        </tr>
        
        <?php
        } else {
            // If the cart is empty
            echo "<tr><td colspan='5' align='center'>Order is Empty!</td></tr>";
        }
        ?>
    </table>
</form>

<!-- Footer Section -->
<div>&nbsp;</div>
<br />
<br />
<div id="footer">Copyrights & Designed by @Auto Spare Zone</div>
