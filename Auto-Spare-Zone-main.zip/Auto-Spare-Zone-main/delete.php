
<?php
 	include("dbconnect.php");
	extract($_POST);
	session_start();


	$did=$_REQUEST['id'];
	
	$qt=mysqli_query($conn,"delete from product where id='$did'");
	if($qt){?>
	
	<script> alert('Deleted successfully')
window.location.href=("viewp.php");</script>
	<?php }
	
	
?>	


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
</body>
</html>
