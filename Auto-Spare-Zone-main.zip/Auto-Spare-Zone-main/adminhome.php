<?php
 	include("dbconnect.php");
	extract($_POST);
	session_start();
if(isset($_POST['btn']))
{




		
		
		
		
 			$imgpath=$_FILES['file1']['name'];
			$errors= array();
   			 $fname = $_FILES['file1']['name'];
    		$file_tmp =$_FILES['file1']['tmp_name'];
    		$qs = move_uploaded_file($_FILES['file1']['tmp_name'],"images/".$fname);
			if($qs)
			{
				echo "<script>alert('file uploaded')</script>";
	
			
			}
			else
			{
			echo "<script>alert(' upload failed')</script>";
			}
			$img=$fname;
		
		$qry=mysqli_query($conn,"insert into product values('','$brand','$name','$img','$wei','$desc','$price','$usage','$qty')");
	if($qry)
	{
	
	echo "<script>alert('inserted sucessfully')</script>";
	
	}
	else
	{
	
	
		echo "failed";
	
}

}

?>

<html>
<title>Spare Parts</title>
<style>

p
{
	color:#333300;
	text-align: center;
	text-transform: uppercase;
	 font-size:35px;
}

ul {
	padding:25px;
	
  list-style-type: none;
  overflow: hidden;
  background:#333300;
   background-repeat: no-repeat;
   background-size: 1420px  200px;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
   border-radius:10px;
}

li {
  float: left;
}

li a {
  display: block;
  color: #ffffff;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #666600;
}

.active {
  background-color: #666600;
}

#footer {
  border: 2px solid #333300;
  padding: 25px;
  background:#333300;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:20px;
}
#bg1 {

  padding:150px;
  background:url("images/car.jpg");
  background-repeat: no-repeat;
  background-size: 1420px  300px;
  border-radius:5px;
   border-radius:10px;
    text-align:left;
   font-size:35px;
   color:#cce6ff;
}

</style>
</head>
<ul>
	 <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
  <li><a class="active" href="adminhome.php"><strong>admin Home</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="viewp.php"><strong>View Products</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="views.php"><strong>View Sales</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="viewu.php"><strong>View Users</a></li>
   <li><a href="#">&nbsp;</a></li>
   <li><a href="index.php"><strong>LogOut</a></li>
</ul>

<br />
<br />
<p>Auto Spare Zone</p>
<div id="bg1"></div>


 <form id="f1" name="f1" method="post" action="#" enctype="multipart/form-data">
  <table width="34%" border="0" align="center">
		
	
	<tr>
      <td width="39%">&nbsp;</td>
      <td width="61%">&nbsp;</td>
    </tr>
	
    <tr>
      <td colspan="2"  align="center" ><div class="style5"><h3>Add New Spare Parts</h></div></td>
    </tr>
	
	
	
	
	<tr>
     
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
	
	
	
	 <tr>
     
      <td>Brand Name</td>
      <td><input name="brand" type="text" id="brand" required /></td>
    
    </tr>
	
	<tr>
     
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
	
	
	  <tr>
     
      <td>Product Name</td>
      <td><input name="name" type="text" id="name" required /></td>
     
    </tr>
	
	
<tr>
     
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
	
	<tr>
      
      <td>product Image</td>
      <td><input name="file1" type="file" id="file1" required /></td>
     
    </tr>
	
	<tr>
     
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
	
	
	
	
	<tr>
     
      <td>Weight</td>
      <td><input name="wei" type="text" id="wei" required /></td>
     
    </tr>
	
	
	
	
	
	<tr>
     
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
	
	<tr>
     
      <td>Description</td>
      <td><textarea name="desc" ></textarea></td>
     
    </tr>
	
	
	<tr>
     
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
	
	
	<tr>
     
      <td>Price</td>
      <td><input name="price" type="text" id="price" required /></td>
    
    </tr>
	
	<tr>
     
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
	
	
	
	
	<tr>
     
      <td>Usage</td>
      <td><input name="usage" type="text" id="usage" required /></td>
    
    </tr>
	
	<tr>
     
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
	
	<tr>
     
      <td>Quantity</td>
      <td><input name="qty" type="text" id="qty" required /></td>
    
    </tr>
	
	
	
	<tr>
     
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
	
	
	<tr>
     
      <td>&nbsp;</td>
      <td><input name="btn" type="submit" id="btn" value="Submit" />
      <input type="reset" name="Submit2" value="Reset" /></td>
    </tr>
  </table>
</form>



<div> &nbsp;</div>
<br>
<br>
<div id="footer"> copyrights & designedby@auto Spare Parts</div>