<?php
include("dbconnect.php");
session_start();

if (isset($_POST['update_qty'])) {
    $id = $_POST['id'];
    $qty = $_POST['qty'];

    // Ensure qty is a valid number and greater than or equal to 0
    if (is_numeric($qty) && $qty >= 0) {
        $qry = "UPDATE product SET qty = '$qty' WHERE id = '$id'";

        if (mysqli_query($conn, $qry)) {
            // Redirect to the product view page with a success message
            header("Location: viewp.php?message=Quantity updated successfully");
        } else {
            // Handle error and redirect to the product view page with an error message
            header("Location: viewp.php?error=Failed to update quantity");
        }
    } else {
        // Invalid quantity, redirect back with an error message
        header("Location: viewp.php?error=Invalid quantity value");
    }
}
?>
