<?php
$servername = "localhost";
$username = "";
$password = "";
$mydb = "autospareparts";

$conn = mysqli_connect($servername, $username, $password, $mydb);

if (!$conn) {
    // Add more detailed error logging
    die("Connection failed: " . mysqli_connect_error() . " | Error Code: " . mysqli_connect_errno());
} else {
    echo "Connected successfully";  // You can remove this after debugging
}
?>
