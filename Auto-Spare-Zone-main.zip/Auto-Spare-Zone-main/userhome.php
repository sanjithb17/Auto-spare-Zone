<?php
session_start();
include("dbconnect.php");

$uid=$_SESSION['id'];


?> 

<html>
<title>Spare Parts</title>
<style>

p
{
	color:#333300;
	text-align: center;
	text-transform: uppercase;
	 font-size:35px;
}

ul {
	padding:25px;
	
  list-style-type: none;
  overflow: hidden;
  background:#333300;
   background-repeat: no-repeat;
   background-size: 1420px  200px;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
   border-radius:10px;
}

li {
  float: left;
}

li a {
  display: block;
  color: #ffffff;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #666600;
}

.active {
  background-color: #666600;
}

#footer {
  border: 2px solid #333300;
  padding: 25px;
  background:#333300;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:20px;
}
#bg1 {

  padding:150px;
  background:url("images/car.jpg");
  background-repeat: no-repeat;
  background-size: 1420px  300px;
  border-radius:5px;
   border-radius:10px;
    text-align:left;
   font-size:35px;
   color:#cce6ff;
}

</style>
</head>
<ul>
	 <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
  <li><a class="active" href="userhome.php"><strong>User Home Page</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="addcart.php"><strong>Add Cart</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="view.php"><strong>View Buying Product</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="index.php"><strong>LogOut</a></li>
</ul>

<br />
<br />
<p>Auto Spare Zone</p>
<div id="bg1"></div>


<table width="80%" align="center" style="border-spacing: 0; border-collapse: separate;">
    <tr>
        <td style="padding: 20px 0; text-align: center;">
            <h2 style="color: #333; font-family: Arial, sans-serif; margin: 0;">View Products</h2>
        </td>
    </tr>
    
    <?php
    $qry = mysqli_query($conn, "select * from product");
    while($row = mysqli_fetch_array($qry)) {
    ?>
    <tr>
        <td>
            <div style="background: #ffffff; 
                        border-radius: 8px; 
                        box-shadow: 0 2px 4px rgba(0,0,0,0.1); 
                        margin: 20px 0; 
                        padding: 20px; 
                        display: flex; 
                        flex-wrap: wrap;">
                
                <!-- Product Image -->
                <div style="width: 200px; padding: 10px;">
                    <img src="images/<?php echo $row['img']; ?>" 
                         style="width: 100%; 
                                height: auto; 
                                border-radius: 6px; 
                                object-fit: cover;">
                </div>
                
                <!-- Product Details -->
                <div style="flex: 1; padding: 10px;">
                    <div style="margin-bottom: 15px;">
                        <span style="font-weight: bold; 
                                   color: #666; 
                                   display: inline-block; 
                                   width: 120px;">Brand Name:</span>
                        <span style="color: #333;"><?php echo $row['brand']; ?></span>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <span style="font-weight: bold; 
                                   color: #666; 
                                   display: inline-block; 
                                   width: 120px;">Product Name:</span>
                        <span style="color: #333;"><?php echo $row['name']; ?></span>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <span style="font-weight: bold; 
                                   color: #666; 
                                   display: inline-block; 
                                   width: 120px;">Description:</span>
                        <span style="color: #333;"><?php echo $row['desc']; ?></span>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <span style="font-weight: bold; 
                                   color: #666; 
                                   display: inline-block; 
                                   width: 120px;">Usage:</span>
                        <span style="color: #333;"><?php echo $row['usage']; ?></span>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <span style="font-weight: bold; 
                                   color: #666; 
                                   display: inline-block; 
                                   width: 120px;">Quantity:</span>
                        <span style="color: #333;">
					<?php	
						if($row['qty']==0){
						
						echo "out of stock"; }else{
						
						 echo $row['qty']; }?></span>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <span style="font-weight: bold; 
                                   color: #666; 
                                   display: inline-block; 
                                   width: 120px;">Price:</span>
                        <span style="color: #333;">Rs.<?php echo $row['price']; ?></span>
                    </div>
                    
                    <!-- Order Button -->
                    <div style="margin-top: 20px;">
                	<?php	     if($row['qty']==0){
					?>
						
						<p 
                style="display: inline-block;
                                  background-color: #4CAF50;
                                  color: white;
                                  padding: 10px 20px;
                                  text-decoration: none;
                                  border-radius: 4px;
                                  transition: background-color 0.3s;">Coming Soon</p>  <?php }else{  ?> <a href="addtocart.php?&pid=<?php echo $row['id']; ?>&price=<?php echo $row['price']; ?>" 
                           style="display: inline-block;
                                  background-color: #4CAF50;
                                  color: white;
                                  padding: 10px 20px;
                                  text-decoration: none;
                                  border-radius: 4px;
                                  transition: background-color 0.3s;">Order Now</a>
								  
								  <?php } ?>
                    </div>
                </div>
            </div>
        </td>
    </tr>
    <?php
    }
    ?>
</table>




<div> &nbsp;</div>
<br>
<br>
<div id="footer"> copyrights & designedby@auto Spare Parts</div>