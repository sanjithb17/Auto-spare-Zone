

<?php
include("dbconnect.php");
extract($_POST);

?>

<html>
<title>Spare Parts</title>
<style>

p
{
	color:#333300;
	text-align: center;
	text-transform: uppercase;
	 font-size:35px;
}

ul {
	padding:25px;
	
  list-style-type: none;
  overflow: hidden;
  background:#333300;
   background-repeat: no-repeat;
   background-size: 1420px  200px;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
   border-radius:10px;
}

li {
  float: left;
}

li a {
  display: block;
  color: #ffffff;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #666600;
}

.active {
  background-color: #666600;
}

#footer {
  border: 2px solid #333300;
  padding: 25px;
  background:#333300;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:20px;
}
#bg1 {

  padding:150px;
  background:url("images/car.jpg");
  background-repeat: no-repeat;
  background-size: 1420px  300px;
  border-radius:5px;
   border-radius:10px;
    text-align:left;
   font-size:35px;
   color:#cce6ff;
}

</style>
</head>
<ul>
    <li><a href="#"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
    <li><a href="adminhome.php"><strong>admin Home</strong></a></li>
    <li><a href="#"> &nbsp;</a></li>
    <li><a class="active" href="viewp.php"><strong>View Products</strong></a></li>
    <li><a href="#"> &nbsp;</a></li>
    <li><a href="views.php"><strong>View Sales</strong></a></li>
    <li><a href="#"> &nbsp;</a></li>
    <li><a href="viewu.php"><strong>View Users</strong></a></li>
    <li><a href="#"> &nbsp;</a></li>
    <li><a href="index.php"><strong>LogOut</strong></a></li>
</ul>

<br />
<br />
<p>Auto Spare Zone</p>
<div id="bg1"></div>

<table width="102%" align="center">
    <tr>
        <td colspan="10">&nbsp;</td>
    </tr>

    <tr>
        <td width="8%">&nbsp;</td>
        <td width="9%"><div align="center" class="style6"><strong>Id</strong></div></td>
        <td width="9%"><div align="center" class="style6"><strong>Brand</strong></div></td>
        <td width="11%"><div align="center" class="style6"><strong>Product Name</strong></div></td>
        <td width="15%"><div align="center" class="style6"><strong>Price</strong></div></td>
        <td width="16%"><div align="center" class="style6"><strong>Number Of Stock</strong></div></td>
        <td width="13%"><div align="center" class="style6"><strong>Action</strong></div></td>
    </tr>

    <tr>
        <td colspan="10">&nbsp;</td>
    </tr>

    <?php
    $qry = mysqli_query($conn, "SELECT * FROM product");
    while($row = mysqli_fetch_array($qry)) {
    ?>
        <tr>
            <td width="8%">&nbsp;</td>
            <td><div align="center"><?php echo $row['id']; ?></div></td>
            <td><div align="center"><?php echo $row['brand']; ?></div></td>
            <td><div align="center"><?php echo $row['name']; ?></div></td>
            <td><div align="center"><?php echo $row['price']; ?></div></td>
            <td>
                <div align="center">
                    <form action="update_quantity.php" method="POST">
                        <input type="number" name="qty" value="<?php echo $row['qty']; ?>" min="0" required>
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <input type="submit" name="update_qty" value="Update Quantity">
                    </form>
                </div>
            </td>
            <td width="13%"><div align="center"><a href="delete.php?id=<?php echo $row['id']; ?>">Delete Product</a></div></td>
        </tr>

        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td width="16%">&nbsp;</td>
        </tr>
    <?php } ?>
    <tr>
        <td colspan="10" align="center">&nbsp;</td>
    </tr>
</table>

<div>&nbsp;</div>
<br>
<br>
<div id="footer"> copyrights & designedby@auto Spare Parts</div>

</html>
