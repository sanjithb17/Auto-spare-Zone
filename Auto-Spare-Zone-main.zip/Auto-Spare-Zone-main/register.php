<?php
 	include("dbconnect.php");
	extract($_POST);
	session_start();

if(isset($_POST['btn']))
{


$qry=mysqli_query($conn,"insert into register values('','$name','$gender','$age','$email','$phone','$zip','$address','$uname','$psw')");
	if($qry)
	{
	
	echo "<script>alert('inserted sucessfully')</script>";
	
	}
	else
	{
	
	
		echo "failed";
	
}

}

?>






<html>
<title>Spare Parts</title>
<style>

p
{
	color:#333300;
	text-align: center;
	text-transform: uppercase;
	 font-size:35px;
}

ul {
	padding:25px;
	
  list-style-type: none;
  overflow: hidden;
  background:#333300;
   background-repeat: no-repeat;
   background-size: 1420px  200px;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
   border-radius:10px;
}

li {
  float: left;
}

li a {
  display: block;
  color: #ffffff;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #666600;
}

.active {
  background-color: #666600;
}

#footer {
  border: 2px solid #333300;
  padding: 25px;
  background:#333300;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:20px;
}
#bg1 {

  padding:150px;
  background:url("images/car.jpg");
  background-repeat: no-repeat;
  background-size: 1420px  300px;
  border-radius:5px;
   border-radius:10px;
    text-align:left;
   font-size:35px;
   color:#cce6ff;
}

</style>
</head>
<ul>
	 <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
  <li><a  href="index.php"><strong>Home Page</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a  href="admin.php"><strong>Admin login</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a class="active" href="user.php"><strong>User Login</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="about.php"><strong>About Us</a></li>
</ul>

<br />
<br />
<p>Auto Spare Zone</p>
<div id="bg1"></div>



 <form id="f1" name="f1" method="post" action="#">
  <table width="38%" border="0" align="center">
	
    <tr>
          <td colspan="2"  align="center" ><div class="style5"><h3>New User Registration</h></div></td>
    
    </tr>
	
    <tr>
     
      <td width="39%" height="48">Name</td>
      <td width="61%"><input name="name" type="text" id="name" required/>
      </td>
      
    </tr>
	
    <tr>
     
      <td height="39">Gender</td>
      <td><input name="gender" type="radio" value="male" required/>
        Male
          <input name="gender" type="radio" value="female" /> 
          Female</td>
     
    </tr>
    <tr>
     
      <td height="34">Age</td>
      <td>
        <input name="age" type="text" id="age" required/>
      </td>
     
    </tr>
	
    <tr>
     
      <td height="36">Email Id</td>
      <td><input name="email" type="text" id="email" required/></td>
      
    </tr>
	
	
	  <tr>
      <td height="38">Phone Number </span></td>
      <td><input name="phone" type="text" id="phone" required/></td>
      
    </tr>
	
	   <tr>
      <td height="48">Address</td>
      <td><textarea name="address" id="address" required></textarea></td>
       </tr>
	
	
	<tr>
    
      <td height="43">Zipcode</td>
      <td><input type="text" name="zip" id="zip" required></td>
     
    </tr>
	

	

    <tr>
      <td height="39">User Name</td>
      <td><input name="uname" type="text" id="uname" required/></td>
    </tr>
	
	
    <tr>
     <td height="38">Password</td>
      <td><input name="psw" type="password" id="psw" required/></td>
    </tr>
	
	<tr>
      <td height="39">&nbsp;</td>
      <td><input name="btn" type="submit" id="btn" value="Submit" />
      <input type="reset" name="Submit2" value="Reset" /></td>
    </tr>
  </table>
  
</form>

<div> &nbsp;</div>

<div id="footer"> copyrights & designedby@auto Spare Parts</div>