<?php
include("dbconnect.php");
session_start();

// Fetch order ID and amount from URL
$id = isset($_GET['id']) ? $_GET['id'] : null;
$amount = isset($_GET['amount']) ? $_GET['amount'] : 0; // Now amount is fetched correctly

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cno = isset($_POST['cno']) ? $_POST['cno'] : '';
    $cvv = isset($_POST['cvv']) ? $_POST['cvv'] : '';
    $cname = isset($_POST['cname']) ? $_POST['cname'] : '';

    // Basic validations
    if (!preg_match("/^[0-9]{16}$/", $cno)) {
        echo "<script>alert('Invalid Card Number!');</script>";
    } elseif (!preg_match("/^[0-9]{3}$/", $cvv)) {
        echo "<script>alert('Invalid CVV Number!');</script>";
    } elseif (!preg_match("/^[A-Za-z ]{3,32}$/", $cname)) {
        echo "<script>alert('Invalid Card Name!');</script>";
    } else {
        echo "<script>
                alert('Amount Transfer Successful.');
                window.location.href='userhome.php';
              </script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - Spare Parts</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; }
        table { margin: auto; }
        input { padding: 10px; margin: 5px; }
    </style>
</head>
<body>

<h2>Payment Mode</h2>

<p><strong>Order ID:</strong> <?php echo htmlspecialchars($id); ?></p>
<p><strong>Total Amount:</strong> ₹<?php echo number_format($amount, 2); ?></p>

<form method="post" action="">
    <table>
        <tr>
            <td>Enter Card Number:</td>
            <td><input name="cno" type="text" required pattern="[0-9]{16}" maxlength="16"></td>
        </tr>
        <tr>
            <td>CVV Number:</td>
            <td><input name="cvv" type="password" required pattern="[0-9]{3}" maxlength="3"></td>
        </tr>
        <tr>
            <td>Card Name:</td>
            <td><input name="cname" type="text" required pattern="[A-Za-z ]{3,32}"></td>
        </tr>
        <tr>
            <td colspan="2"><input type="submit" value="Pay Now"></td>
        </tr>
    </table>
</form>

</body>
</html>
