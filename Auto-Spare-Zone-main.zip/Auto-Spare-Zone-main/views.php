
<?php
 	include("dbconnect.php");
	extract($_POST);
	session_start();
?>


<html>
<title>Spare Parts</title>
<style>

p
{
	color:#333300;
	text-align: center;
	text-transform: uppercase;
	 font-size:35px;
}

ul {
	padding:25px;
	
  list-style-type: none;
  overflow: hidden;
  background:#333300;
   background-repeat: no-repeat;
   background-size: 1420px  200px;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
   border-radius:10px;
}

li {
  float: left;
}

li a {
  display: block;
  color: #ffffff;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #666600;
}

.active {
  background-color: #666600;
}

#footer {
  border: 2px solid #333300;
  padding: 25px;
  background:#333300;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:20px;
}
#bg1 {

  padding:150px;
  background:url("images/car.jpg");
  background-repeat: no-repeat;
  background-size: 1420px  300px;
  border-radius:5px;
   border-radius:10px;
    text-align:left;
   font-size:35px;
   color:#cce6ff;
}

</style>
</head>
<ul>
	 <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
  <li><a  href="adminhome.php"><strong>admin Home</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="viewp.php"><strong>View Products</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a class="active" href="views.php"><strong>View Sales</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="viewu.php"><strong>View Users</a></li>
   <li><a href="#">&nbsp;</a></li>
   <li><a href="index.php"><strong>LogOut</a></li>
</ul>

<br />
<br>
<p>Auto Spare Zone</p>
<div id="bg1"></div>







<table width="102%" align="center">
	<tr>
		<td colspan="10">&nbsp;</td>
		</tr>
	
		    <tr>
          <td width="9%">&nbsp;</td>
          <td width="10%"><div align="center" class="style6"><strong>Id</strong> </div></td>
		  		   <td width="12%"><div align="center" class="style6"><strong>User Id</strong> </div></td>
		   <td width="12%"><div align="center" class="style6"><strong>Brand</strong> </div></td>
		   <td width="12%"><div align="center" class="style6"><strong>Product Name</strong> </div></td>
		    <td width="13%"><div align="center" class="style6"><strong>Quantity</strong> </div></td>
			 <td width="16%"><div align="center" class="style6"><strong>Price</strong> </div></td>
			  <td width="17%"><div align="center" class="style6"><strong>Amount</strong> </div></td>
        </tr>
		<tr>
		<td colspan="10">&nbsp;</td>
		</tr>
		<?php
		$qry=mysqli_query($conn,"select * from addcart where status='1'");
		$i=1;
		while($row=mysqli_fetch_array($qry))
		{
		$pid=$row['pid'];
		$uid=$row['uid'];
		$qry1=mysqli_query($conn,"select * from product where id='$pid'");
		$row1=mysqli_fetch_array($qry1)
		?>
        <tr>
		 <td width="9%">&nbsp;</td>
		    <td><div align="center"><?php echo $row['id'];?></div></td>
			 <td><div align="center"><?php echo $uid;?></div></td>
			 <td><div align="center"><?php echo $row1['brand'];?></div></td>
		   <td><div align="center"><?php echo $row1['name'];?></div></td>
			  <td><div align="center"><?php echo $row['quantity'];?></div></td>
			 <td><div align="center"><?php echo $row['price'];?></div></td>
			   <td><div align="center"><?php echo $row['amount'];?></div></td>
		 
        </tr>

		 <tr>
		  	 	<td>&nbsp;</td>
		   		<td>&nbsp;</td>
				<td>&nbsp;</td>
			 	<td>&nbsp;</td>
			 	<td>&nbsp;</td>
			 	<td>&nbsp;</td>
				<td width="23%">&nbsp;</td>
		
		
		</tr>
		
        <?php
		$i++;
		}

		?>
				<tr>
		<td colspan="10" align="center">&nbsp;</td>
		</tr>
		
</table>









<div> &nbsp;</div>
<br>
<br>
<div id="footer"> copyrights & designedby@auto Spare Parts</div>