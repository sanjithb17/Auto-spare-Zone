<?php

include("dbconnect.php");

 session_start();

$uid=$_SESSION['id'];


$did=$_REQUEST['did'];
$qry=mysqli_query($conn,"delete from addcart where id=$did");
	if($qry){?>
	
	<script> alert('removed successfully')
window.location.href=("addcart.php");</script>
	
	
	<?php }
	
	
?>	



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
</body>
</html>
